<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fb9336d9f591f9a2685a2a6161c055b323db20a66b4c9ca991c8e617b92544c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fb9336d9f591f9a2685a2a6161c055b323db20a66b4c9ca991c8e617b92544c->enter($__internal_8fb9336d9f591f9a2685a2a6161c055b323db20a66b4c9ca991c8e617b92544c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_61eb73326d1ea1f476487b44dd0160144fe345a3c3fbfd848d7fbb16db7d2f65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61eb73326d1ea1f476487b44dd0160144fe345a3c3fbfd848d7fbb16db7d2f65->enter($__internal_61eb73326d1ea1f476487b44dd0160144fe345a3c3fbfd848d7fbb16db7d2f65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_8fb9336d9f591f9a2685a2a6161c055b323db20a66b4c9ca991c8e617b92544c->leave($__internal_8fb9336d9f591f9a2685a2a6161c055b323db20a66b4c9ca991c8e617b92544c_prof);

        
        $__internal_61eb73326d1ea1f476487b44dd0160144fe345a3c3fbfd848d7fbb16db7d2f65->leave($__internal_61eb73326d1ea1f476487b44dd0160144fe345a3c3fbfd848d7fbb16db7d2f65_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_7bca49cef24a049760e2e7f6a06a6b16a33d2bf426432d3f88f0918e7a5af63e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7bca49cef24a049760e2e7f6a06a6b16a33d2bf426432d3f88f0918e7a5af63e->enter($__internal_7bca49cef24a049760e2e7f6a06a6b16a33d2bf426432d3f88f0918e7a5af63e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c610b6e9ff6075dd56dfa524f1f8a4ea4e875b5601c9ac9e5c5a36845788c31f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c610b6e9ff6075dd56dfa524f1f8a4ea4e875b5601c9ac9e5c5a36845788c31f->enter($__internal_c610b6e9ff6075dd56dfa524f1f8a4ea4e875b5601c9ac9e5c5a36845788c31f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_c610b6e9ff6075dd56dfa524f1f8a4ea4e875b5601c9ac9e5c5a36845788c31f->leave($__internal_c610b6e9ff6075dd56dfa524f1f8a4ea4e875b5601c9ac9e5c5a36845788c31f_prof);

        
        $__internal_7bca49cef24a049760e2e7f6a06a6b16a33d2bf426432d3f88f0918e7a5af63e->leave($__internal_7bca49cef24a049760e2e7f6a06a6b16a33d2bf426432d3f88f0918e7a5af63e_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f0717afe2bd526b0688b792441e4a7d73a7fc98cebe36f39e5740835075ab5eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f0717afe2bd526b0688b792441e4a7d73a7fc98cebe36f39e5740835075ab5eb->enter($__internal_f0717afe2bd526b0688b792441e4a7d73a7fc98cebe36f39e5740835075ab5eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8c80076c9be41ca9bcfdea8d371250edd8b3ec4e76c099561d37730de57c4f5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c80076c9be41ca9bcfdea8d371250edd8b3ec4e76c099561d37730de57c4f5d->enter($__internal_8c80076c9be41ca9bcfdea8d371250edd8b3ec4e76c099561d37730de57c4f5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_8c80076c9be41ca9bcfdea8d371250edd8b3ec4e76c099561d37730de57c4f5d->leave($__internal_8c80076c9be41ca9bcfdea8d371250edd8b3ec4e76c099561d37730de57c4f5d_prof);

        
        $__internal_f0717afe2bd526b0688b792441e4a7d73a7fc98cebe36f39e5740835075ab5eb->leave($__internal_f0717afe2bd526b0688b792441e4a7d73a7fc98cebe36f39e5740835075ab5eb_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_83e3d7ab1914d0aa3ff54f4585eadf137675e395799243291f53e77fd3e71164 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83e3d7ab1914d0aa3ff54f4585eadf137675e395799243291f53e77fd3e71164->enter($__internal_83e3d7ab1914d0aa3ff54f4585eadf137675e395799243291f53e77fd3e71164_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_89fd3fe5c70f4247478e370b0a754cf5d3e9d1bfecf7c1700af600e55df74e0b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89fd3fe5c70f4247478e370b0a754cf5d3e9d1bfecf7c1700af600e55df74e0b->enter($__internal_89fd3fe5c70f4247478e370b0a754cf5d3e9d1bfecf7c1700af600e55df74e0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_89fd3fe5c70f4247478e370b0a754cf5d3e9d1bfecf7c1700af600e55df74e0b->leave($__internal_89fd3fe5c70f4247478e370b0a754cf5d3e9d1bfecf7c1700af600e55df74e0b_prof);

        
        $__internal_83e3d7ab1914d0aa3ff54f4585eadf137675e395799243291f53e77fd3e71164->leave($__internal_83e3d7ab1914d0aa3ff54f4585eadf137675e395799243291f53e77fd3e71164_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_f42626ae4f0b7a8906292882ccde51bf7db28422b62c0709daf45de135517dfe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f42626ae4f0b7a8906292882ccde51bf7db28422b62c0709daf45de135517dfe->enter($__internal_f42626ae4f0b7a8906292882ccde51bf7db28422b62c0709daf45de135517dfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_0cf3cfcec2cb93a69df28a6656750c6bf06ddf69deea07ec566d433f540c0e2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cf3cfcec2cb93a69df28a6656750c6bf06ddf69deea07ec566d433f540c0e2c->enter($__internal_0cf3cfcec2cb93a69df28a6656750c6bf06ddf69deea07ec566d433f540c0e2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_0cf3cfcec2cb93a69df28a6656750c6bf06ddf69deea07ec566d433f540c0e2c->leave($__internal_0cf3cfcec2cb93a69df28a6656750c6bf06ddf69deea07ec566d433f540c0e2c_prof);

        
        $__internal_f42626ae4f0b7a8906292882ccde51bf7db28422b62c0709daf45de135517dfe->leave($__internal_f42626ae4f0b7a8906292882ccde51bf7db28422b62c0709daf45de135517dfe_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_1d98d9b4e861724b1861cc4745fa1fef90b7195a702f7519987f1532f8daf870 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d98d9b4e861724b1861cc4745fa1fef90b7195a702f7519987f1532f8daf870->enter($__internal_1d98d9b4e861724b1861cc4745fa1fef90b7195a702f7519987f1532f8daf870_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d0a31efecdadd5c4df9fa9a87a0ca5890801bd1fbf9140d38215528411191869 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0a31efecdadd5c4df9fa9a87a0ca5890801bd1fbf9140d38215528411191869->enter($__internal_d0a31efecdadd5c4df9fa9a87a0ca5890801bd1fbf9140d38215528411191869_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_d0a31efecdadd5c4df9fa9a87a0ca5890801bd1fbf9140d38215528411191869->leave($__internal_d0a31efecdadd5c4df9fa9a87a0ca5890801bd1fbf9140d38215528411191869_prof);

        
        $__internal_1d98d9b4e861724b1861cc4745fa1fef90b7195a702f7519987f1532f8daf870->leave($__internal_1d98d9b4e861724b1861cc4745fa1fef90b7195a702f7519987f1532f8daf870_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_32c9ed5c9ec097a43a31054f11297354ef9d17ee3a41cbc1cdd1cb4b92b97971 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32c9ed5c9ec097a43a31054f11297354ef9d17ee3a41cbc1cdd1cb4b92b97971->enter($__internal_32c9ed5c9ec097a43a31054f11297354ef9d17ee3a41cbc1cdd1cb4b92b97971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_7faf0c9ec220c709475470cacc10fec3b74e315905b584a5e9f2e481e3857d48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7faf0c9ec220c709475470cacc10fec3b74e315905b584a5e9f2e481e3857d48->enter($__internal_7faf0c9ec220c709475470cacc10fec3b74e315905b584a5e9f2e481e3857d48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_7faf0c9ec220c709475470cacc10fec3b74e315905b584a5e9f2e481e3857d48->leave($__internal_7faf0c9ec220c709475470cacc10fec3b74e315905b584a5e9f2e481e3857d48_prof);

        
        $__internal_32c9ed5c9ec097a43a31054f11297354ef9d17ee3a41cbc1cdd1cb4b92b97971->leave($__internal_32c9ed5c9ec097a43a31054f11297354ef9d17ee3a41cbc1cdd1cb4b92b97971_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_b1cb753ff4d1aec3e2b014a8dbfb32bd342cd3abc2af4ddc95298756b6cb7f83 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b1cb753ff4d1aec3e2b014a8dbfb32bd342cd3abc2af4ddc95298756b6cb7f83->enter($__internal_b1cb753ff4d1aec3e2b014a8dbfb32bd342cd3abc2af4ddc95298756b6cb7f83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_bf781338d617212f47be9c1342304dfc8b635d0e838b1d372f5e748049b42b67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf781338d617212f47be9c1342304dfc8b635d0e838b1d372f5e748049b42b67->enter($__internal_bf781338d617212f47be9c1342304dfc8b635d0e838b1d372f5e748049b42b67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2017 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_bf781338d617212f47be9c1342304dfc8b635d0e838b1d372f5e748049b42b67->leave($__internal_bf781338d617212f47be9c1342304dfc8b635d0e838b1d372f5e748049b42b67_prof);

        
        $__internal_b1cb753ff4d1aec3e2b014a8dbfb32bd342cd3abc2af4ddc95298756b6cb7f83->leave($__internal_b1cb753ff4d1aec3e2b014a8dbfb32bd342cd3abc2af4ddc95298756b6cb7f83_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_ad6f31110317bf43436a9d3e3606f74ddb149e19f8945a2bf95bd981ee4e767b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad6f31110317bf43436a9d3e3606f74ddb149e19f8945a2bf95bd981ee4e767b->enter($__internal_ad6f31110317bf43436a9d3e3606f74ddb149e19f8945a2bf95bd981ee4e767b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_048dbf618ebfe3bd72d486a6b4d0c2c1ee7431e947c6d73bd1356afc9a9d3fa3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_048dbf618ebfe3bd72d486a6b4d0c2c1ee7431e947c6d73bd1356afc9a9d3fa3->enter($__internal_048dbf618ebfe3bd72d486a6b4d0c2c1ee7431e947c6d73bd1356afc9a9d3fa3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_048dbf618ebfe3bd72d486a6b4d0c2c1ee7431e947c6d73bd1356afc9a9d3fa3->leave($__internal_048dbf618ebfe3bd72d486a6b4d0c2c1ee7431e947c6d73bd1356afc9a9d3fa3_prof);

        
        $__internal_ad6f31110317bf43436a9d3e3606f74ddb149e19f8945a2bf95bd981ee4e767b->leave($__internal_ad6f31110317bf43436a9d3e3606f74ddb149e19f8945a2bf95bd981ee4e767b_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2017 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Users\\paunov\\Desktop\\php\\Calculator-Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
