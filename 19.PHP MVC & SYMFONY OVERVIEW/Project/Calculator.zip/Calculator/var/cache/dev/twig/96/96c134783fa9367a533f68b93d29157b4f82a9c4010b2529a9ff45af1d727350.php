<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_793e62050aded38dbd530506821ad2046ac130fb98a0f93543a0be7f2195cf27 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_793e62050aded38dbd530506821ad2046ac130fb98a0f93543a0be7f2195cf27->enter($__internal_793e62050aded38dbd530506821ad2046ac130fb98a0f93543a0be7f2195cf27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_900317ac6d06a3b656abcbbf583bbae19920f492cd071e18ae7a1ee10070f176 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_900317ac6d06a3b656abcbbf583bbae19920f492cd071e18ae7a1ee10070f176->enter($__internal_900317ac6d06a3b656abcbbf583bbae19920f492cd071e18ae7a1ee10070f176_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_793e62050aded38dbd530506821ad2046ac130fb98a0f93543a0be7f2195cf27->leave($__internal_793e62050aded38dbd530506821ad2046ac130fb98a0f93543a0be7f2195cf27_prof);

        
        $__internal_900317ac6d06a3b656abcbbf583bbae19920f492cd071e18ae7a1ee10070f176->leave($__internal_900317ac6d06a3b656abcbbf583bbae19920f492cd071e18ae7a1ee10070f176_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c71bc869ff8296b61b39c9d4609859e827a0a5c1f5a44ee1fbf84359b7e46408 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c71bc869ff8296b61b39c9d4609859e827a0a5c1f5a44ee1fbf84359b7e46408->enter($__internal_c71bc869ff8296b61b39c9d4609859e827a0a5c1f5a44ee1fbf84359b7e46408_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_ae54bbfb844bfa4fbe45e2f5fd58667e2203c3af40664d80c3fc3b892453c430 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae54bbfb844bfa4fbe45e2f5fd58667e2203c3af40664d80c3fc3b892453c430->enter($__internal_ae54bbfb844bfa4fbe45e2f5fd58667e2203c3af40664d80c3fc3b892453c430_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_ae54bbfb844bfa4fbe45e2f5fd58667e2203c3af40664d80c3fc3b892453c430->leave($__internal_ae54bbfb844bfa4fbe45e2f5fd58667e2203c3af40664d80c3fc3b892453c430_prof);

        
        $__internal_c71bc869ff8296b61b39c9d4609859e827a0a5c1f5a44ee1fbf84359b7e46408->leave($__internal_c71bc869ff8296b61b39c9d4609859e827a0a5c1f5a44ee1fbf84359b7e46408_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_958a63de25451205279db538544ca2a30260fa649116da57f4c0e688d855cb48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_958a63de25451205279db538544ca2a30260fa649116da57f4c0e688d855cb48->enter($__internal_958a63de25451205279db538544ca2a30260fa649116da57f4c0e688d855cb48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e8f6425f64fa3f20a4a652a834cacd4a7ea4a84f6d11dbaeed1ff6f9f99d56e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8f6425f64fa3f20a4a652a834cacd4a7ea4a84f6d11dbaeed1ff6f9f99d56e3->enter($__internal_e8f6425f64fa3f20a4a652a834cacd4a7ea4a84f6d11dbaeed1ff6f9f99d56e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e8f6425f64fa3f20a4a652a834cacd4a7ea4a84f6d11dbaeed1ff6f9f99d56e3->leave($__internal_e8f6425f64fa3f20a4a652a834cacd4a7ea4a84f6d11dbaeed1ff6f9f99d56e3_prof);

        
        $__internal_958a63de25451205279db538544ca2a30260fa649116da57f4c0e688d855cb48->leave($__internal_958a63de25451205279db538544ca2a30260fa649116da57f4c0e688d855cb48_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_a53455444dcf9416b0e4f58e214784cce73974980673a55a18793a8aab2fad88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a53455444dcf9416b0e4f58e214784cce73974980673a55a18793a8aab2fad88->enter($__internal_a53455444dcf9416b0e4f58e214784cce73974980673a55a18793a8aab2fad88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9e181804b6c773587b39f93f1c326a8efa4de074cb95aee689d4d7cf382de616 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e181804b6c773587b39f93f1c326a8efa4de074cb95aee689d4d7cf382de616->enter($__internal_9e181804b6c773587b39f93f1c326a8efa4de074cb95aee689d4d7cf382de616_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_9e181804b6c773587b39f93f1c326a8efa4de074cb95aee689d4d7cf382de616->leave($__internal_9e181804b6c773587b39f93f1c326a8efa4de074cb95aee689d4d7cf382de616_prof);

        
        $__internal_a53455444dcf9416b0e4f58e214784cce73974980673a55a18793a8aab2fad88->leave($__internal_a53455444dcf9416b0e4f58e214784cce73974980673a55a18793a8aab2fad88_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\paunov\\Desktop\\php\\Calculator-Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
