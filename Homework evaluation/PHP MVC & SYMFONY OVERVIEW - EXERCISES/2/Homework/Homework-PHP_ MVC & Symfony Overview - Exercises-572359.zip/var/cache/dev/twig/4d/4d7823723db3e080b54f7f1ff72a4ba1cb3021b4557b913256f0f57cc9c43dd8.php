<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_99b2a225cb70aa4a8d48984f92fa0c34ec0fea32a96ff1e63d94ed7465a2ded8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e58aea40d3916e0454fbb09b2816579f6006cf2dfc717153b3fe6d1a6bdd344 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e58aea40d3916e0454fbb09b2816579f6006cf2dfc717153b3fe6d1a6bdd344->enter($__internal_6e58aea40d3916e0454fbb09b2816579f6006cf2dfc717153b3fe6d1a6bdd344_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_5d94d5a21152dac2afd5c628afd4af2c211252919ac20b26f84463581baa81da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d94d5a21152dac2afd5c628afd4af2c211252919ac20b26f84463581baa81da->enter($__internal_5d94d5a21152dac2afd5c628afd4af2c211252919ac20b26f84463581baa81da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e58aea40d3916e0454fbb09b2816579f6006cf2dfc717153b3fe6d1a6bdd344->leave($__internal_6e58aea40d3916e0454fbb09b2816579f6006cf2dfc717153b3fe6d1a6bdd344_prof);

        
        $__internal_5d94d5a21152dac2afd5c628afd4af2c211252919ac20b26f84463581baa81da->leave($__internal_5d94d5a21152dac2afd5c628afd4af2c211252919ac20b26f84463581baa81da_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_c1454c72dd3ed93885e7a551ba2950960b76f9eb7ba690ea2d3e383dce7317f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1454c72dd3ed93885e7a551ba2950960b76f9eb7ba690ea2d3e383dce7317f1->enter($__internal_c1454c72dd3ed93885e7a551ba2950960b76f9eb7ba690ea2d3e383dce7317f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_2e052ff29002cc780aa7e13afdb17360226c76c1e2b5c6e3c47d314e609b4ce7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e052ff29002cc780aa7e13afdb17360226c76c1e2b5c6e3c47d314e609b4ce7->enter($__internal_2e052ff29002cc780aa7e13afdb17360226c76c1e2b5c6e3c47d314e609b4ce7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_2e052ff29002cc780aa7e13afdb17360226c76c1e2b5c6e3c47d314e609b4ce7->leave($__internal_2e052ff29002cc780aa7e13afdb17360226c76c1e2b5c6e3c47d314e609b4ce7_prof);

        
        $__internal_c1454c72dd3ed93885e7a551ba2950960b76f9eb7ba690ea2d3e383dce7317f1->leave($__internal_c1454c72dd3ed93885e7a551ba2950960b76f9eb7ba690ea2d3e383dce7317f1_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e5e9908380878691bf77364d74f365742d9f1dd213f4436b35157145f2a0b1b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5e9908380878691bf77364d74f365742d9f1dd213f4436b35157145f2a0b1b2->enter($__internal_e5e9908380878691bf77364d74f365742d9f1dd213f4436b35157145f2a0b1b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_22b23db4229919ac637a2e580d45a12a822d4868dcec93f1103382ed3876b89e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22b23db4229919ac637a2e580d45a12a822d4868dcec93f1103382ed3876b89e->enter($__internal_22b23db4229919ac637a2e580d45a12a822d4868dcec93f1103382ed3876b89e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_22b23db4229919ac637a2e580d45a12a822d4868dcec93f1103382ed3876b89e->leave($__internal_22b23db4229919ac637a2e580d45a12a822d4868dcec93f1103382ed3876b89e_prof);

        
        $__internal_e5e9908380878691bf77364d74f365742d9f1dd213f4436b35157145f2a0b1b2->leave($__internal_e5e9908380878691bf77364d74f365742d9f1dd213f4436b35157145f2a0b1b2_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_6c6ce64494a62c359664e8748126966584457243ded35f945e52f008422a3213 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c6ce64494a62c359664e8748126966584457243ded35f945e52f008422a3213->enter($__internal_6c6ce64494a62c359664e8748126966584457243ded35f945e52f008422a3213_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_275f68b08395075f11bc7e3a275e63ec0080f5334127a455ff32c3d52d2b4e24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_275f68b08395075f11bc7e3a275e63ec0080f5334127a455ff32c3d52d2b4e24->enter($__internal_275f68b08395075f11bc7e3a275e63ec0080f5334127a455ff32c3d52d2b4e24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_275f68b08395075f11bc7e3a275e63ec0080f5334127a455ff32c3d52d2b4e24->leave($__internal_275f68b08395075f11bc7e3a275e63ec0080f5334127a455ff32c3d52d2b4e24_prof);

        
        $__internal_6c6ce64494a62c359664e8748126966584457243ded35f945e52f008422a3213->leave($__internal_6c6ce64494a62c359664e8748126966584457243ded35f945e52f008422a3213_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\user\\Desktop\\calc\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
