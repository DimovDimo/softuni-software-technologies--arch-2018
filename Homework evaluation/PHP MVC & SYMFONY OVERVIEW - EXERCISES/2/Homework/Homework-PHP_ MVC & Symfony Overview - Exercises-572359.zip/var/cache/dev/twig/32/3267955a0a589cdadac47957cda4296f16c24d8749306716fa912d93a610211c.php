<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9e32ce2b27c728ca18a4e4e1a2f2c724912f23b00d09e717552f3940b685c08 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e9e32ce2b27c728ca18a4e4e1a2f2c724912f23b00d09e717552f3940b685c08->enter($__internal_e9e32ce2b27c728ca18a4e4e1a2f2c724912f23b00d09e717552f3940b685c08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2534794669abeb37dca741757ce2670f4d28b21f07083e37a6cc75b9c387e9a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2534794669abeb37dca741757ce2670f4d28b21f07083e37a6cc75b9c387e9a9->enter($__internal_2534794669abeb37dca741757ce2670f4d28b21f07083e37a6cc75b9c387e9a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_e9e32ce2b27c728ca18a4e4e1a2f2c724912f23b00d09e717552f3940b685c08->leave($__internal_e9e32ce2b27c728ca18a4e4e1a2f2c724912f23b00d09e717552f3940b685c08_prof);

        
        $__internal_2534794669abeb37dca741757ce2670f4d28b21f07083e37a6cc75b9c387e9a9->leave($__internal_2534794669abeb37dca741757ce2670f4d28b21f07083e37a6cc75b9c387e9a9_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_82812b5a775b7caec86ee8ae96aeb5e60f97efec8b13a18c6cf6e997403a7c02 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82812b5a775b7caec86ee8ae96aeb5e60f97efec8b13a18c6cf6e997403a7c02->enter($__internal_82812b5a775b7caec86ee8ae96aeb5e60f97efec8b13a18c6cf6e997403a7c02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e894a12af468783ea71b65e762b78c0818d73354601cebd11ae16fb05e970a86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e894a12af468783ea71b65e762b78c0818d73354601cebd11ae16fb05e970a86->enter($__internal_e894a12af468783ea71b65e762b78c0818d73354601cebd11ae16fb05e970a86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_e894a12af468783ea71b65e762b78c0818d73354601cebd11ae16fb05e970a86->leave($__internal_e894a12af468783ea71b65e762b78c0818d73354601cebd11ae16fb05e970a86_prof);

        
        $__internal_82812b5a775b7caec86ee8ae96aeb5e60f97efec8b13a18c6cf6e997403a7c02->leave($__internal_82812b5a775b7caec86ee8ae96aeb5e60f97efec8b13a18c6cf6e997403a7c02_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4d7486772ed6293c05fb2c324350e6da40e18a65e43239698a0815231f850cb9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d7486772ed6293c05fb2c324350e6da40e18a65e43239698a0815231f850cb9->enter($__internal_4d7486772ed6293c05fb2c324350e6da40e18a65e43239698a0815231f850cb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_df13475c2aae9d6b1b633241028c126b7d9d3352cf3f0b21816911db83117a9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df13475c2aae9d6b1b633241028c126b7d9d3352cf3f0b21816911db83117a9c->enter($__internal_df13475c2aae9d6b1b633241028c126b7d9d3352cf3f0b21816911db83117a9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_df13475c2aae9d6b1b633241028c126b7d9d3352cf3f0b21816911db83117a9c->leave($__internal_df13475c2aae9d6b1b633241028c126b7d9d3352cf3f0b21816911db83117a9c_prof);

        
        $__internal_4d7486772ed6293c05fb2c324350e6da40e18a65e43239698a0815231f850cb9->leave($__internal_4d7486772ed6293c05fb2c324350e6da40e18a65e43239698a0815231f850cb9_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_bb4e13508f1d6affe8caa5c453bc892b5f428b38a43ff1781384151594dcfe46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb4e13508f1d6affe8caa5c453bc892b5f428b38a43ff1781384151594dcfe46->enter($__internal_bb4e13508f1d6affe8caa5c453bc892b5f428b38a43ff1781384151594dcfe46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_d8d00ffa6a6bdbb8e1ab8ff70d5ceb24e67726698ba0f3af2cad665b90b17bf4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8d00ffa6a6bdbb8e1ab8ff70d5ceb24e67726698ba0f3af2cad665b90b17bf4->enter($__internal_d8d00ffa6a6bdbb8e1ab8ff70d5ceb24e67726698ba0f3af2cad665b90b17bf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_d8d00ffa6a6bdbb8e1ab8ff70d5ceb24e67726698ba0f3af2cad665b90b17bf4->leave($__internal_d8d00ffa6a6bdbb8e1ab8ff70d5ceb24e67726698ba0f3af2cad665b90b17bf4_prof);

        
        $__internal_bb4e13508f1d6affe8caa5c453bc892b5f428b38a43ff1781384151594dcfe46->leave($__internal_bb4e13508f1d6affe8caa5c453bc892b5f428b38a43ff1781384151594dcfe46_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_d214af02dba5bd4f64e88af59efd587a69559d33fbd5d53b38f5526d80dc4b1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d214af02dba5bd4f64e88af59efd587a69559d33fbd5d53b38f5526d80dc4b1b->enter($__internal_d214af02dba5bd4f64e88af59efd587a69559d33fbd5d53b38f5526d80dc4b1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_48fb985411be0912b973d6a79f2622f4d580b67f923705b89c8c866dca8dfec5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48fb985411be0912b973d6a79f2622f4d580b67f923705b89c8c866dca8dfec5->enter($__internal_48fb985411be0912b973d6a79f2622f4d580b67f923705b89c8c866dca8dfec5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_48fb985411be0912b973d6a79f2622f4d580b67f923705b89c8c866dca8dfec5->leave($__internal_48fb985411be0912b973d6a79f2622f4d580b67f923705b89c8c866dca8dfec5_prof);

        
        $__internal_d214af02dba5bd4f64e88af59efd587a69559d33fbd5d53b38f5526d80dc4b1b->leave($__internal_d214af02dba5bd4f64e88af59efd587a69559d33fbd5d53b38f5526d80dc4b1b_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_be62a6ba746ff2a4f2c10d5a3b8a3e3907da1b6b8e57462e0b53f45d78e35cb7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be62a6ba746ff2a4f2c10d5a3b8a3e3907da1b6b8e57462e0b53f45d78e35cb7->enter($__internal_be62a6ba746ff2a4f2c10d5a3b8a3e3907da1b6b8e57462e0b53f45d78e35cb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_932d881cb182c14d92e654c5900ee16fa94d2a5f111f4b51ba76933dedf5b8cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_932d881cb182c14d92e654c5900ee16fa94d2a5f111f4b51ba76933dedf5b8cc->enter($__internal_932d881cb182c14d92e654c5900ee16fa94d2a5f111f4b51ba76933dedf5b8cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_932d881cb182c14d92e654c5900ee16fa94d2a5f111f4b51ba76933dedf5b8cc->leave($__internal_932d881cb182c14d92e654c5900ee16fa94d2a5f111f4b51ba76933dedf5b8cc_prof);

        
        $__internal_be62a6ba746ff2a4f2c10d5a3b8a3e3907da1b6b8e57462e0b53f45d78e35cb7->leave($__internal_be62a6ba746ff2a4f2c10d5a3b8a3e3907da1b6b8e57462e0b53f45d78e35cb7_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_2dcb9c3748a8649dbd5779a4a8359bc7f2d07359fc266ace14a5b63c86fbd809 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2dcb9c3748a8649dbd5779a4a8359bc7f2d07359fc266ace14a5b63c86fbd809->enter($__internal_2dcb9c3748a8649dbd5779a4a8359bc7f2d07359fc266ace14a5b63c86fbd809_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_576cdebffc98357b5814e707e6338a2ccd0d657b75998563a951a08f116ae439 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_576cdebffc98357b5814e707e6338a2ccd0d657b75998563a951a08f116ae439->enter($__internal_576cdebffc98357b5814e707e6338a2ccd0d657b75998563a951a08f116ae439_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_576cdebffc98357b5814e707e6338a2ccd0d657b75998563a951a08f116ae439->leave($__internal_576cdebffc98357b5814e707e6338a2ccd0d657b75998563a951a08f116ae439_prof);

        
        $__internal_2dcb9c3748a8649dbd5779a4a8359bc7f2d07359fc266ace14a5b63c86fbd809->leave($__internal_2dcb9c3748a8649dbd5779a4a8359bc7f2d07359fc266ace14a5b63c86fbd809_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_b9ac523326dad83446cc403d0052489ff1c45e9394824ae28b6cc88b400b4ae1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b9ac523326dad83446cc403d0052489ff1c45e9394824ae28b6cc88b400b4ae1->enter($__internal_b9ac523326dad83446cc403d0052489ff1c45e9394824ae28b6cc88b400b4ae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_80e375b79dd836b82e0020dc47f5d644b5cc03faad90f45eeed54b758efff317 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80e375b79dd836b82e0020dc47f5d644b5cc03faad90f45eeed54b758efff317->enter($__internal_80e375b79dd836b82e0020dc47f5d644b5cc03faad90f45eeed54b758efff317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_80e375b79dd836b82e0020dc47f5d644b5cc03faad90f45eeed54b758efff317->leave($__internal_80e375b79dd836b82e0020dc47f5d644b5cc03faad90f45eeed54b758efff317_prof);

        
        $__internal_b9ac523326dad83446cc403d0052489ff1c45e9394824ae28b6cc88b400b4ae1->leave($__internal_b9ac523326dad83446cc403d0052489ff1c45e9394824ae28b6cc88b400b4ae1_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3235badbfd0caa649d952e7cfa809282a4c6006582525525f2b50c30ab47d757 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3235badbfd0caa649d952e7cfa809282a4c6006582525525f2b50c30ab47d757->enter($__internal_3235badbfd0caa649d952e7cfa809282a4c6006582525525f2b50c30ab47d757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_4b5251d798e5af71dfb99c920c568c5c2d1537a1902700ac3cbc13be3e4ab033 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b5251d798e5af71dfb99c920c568c5c2d1537a1902700ac3cbc13be3e4ab033->enter($__internal_4b5251d798e5af71dfb99c920c568c5c2d1537a1902700ac3cbc13be3e4ab033_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_4b5251d798e5af71dfb99c920c568c5c2d1537a1902700ac3cbc13be3e4ab033->leave($__internal_4b5251d798e5af71dfb99c920c568c5c2d1537a1902700ac3cbc13be3e4ab033_prof);

        
        $__internal_3235badbfd0caa649d952e7cfa809282a4c6006582525525f2b50c30ab47d757->leave($__internal_3235badbfd0caa649d952e7cfa809282a4c6006582525525f2b50c30ab47d757_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Users\\user\\Desktop\\calc\\Calculator\\app\\Resources\\views\\base.html.twig");
    }
}
