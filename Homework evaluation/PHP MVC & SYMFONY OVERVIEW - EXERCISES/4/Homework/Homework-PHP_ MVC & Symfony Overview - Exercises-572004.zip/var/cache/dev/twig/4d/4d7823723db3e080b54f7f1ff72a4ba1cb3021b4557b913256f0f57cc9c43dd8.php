<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_99b2a225cb70aa4a8d48984f92fa0c34ec0fea32a96ff1e63d94ed7465a2ded8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1d5b96ccac9f9223ed0c019be640f3ffe653cac69486c0b983a0f67257cc5ce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1d5b96ccac9f9223ed0c019be640f3ffe653cac69486c0b983a0f67257cc5ce->enter($__internal_d1d5b96ccac9f9223ed0c019be640f3ffe653cac69486c0b983a0f67257cc5ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_53a7df41e009d4a87e327717c3fa7058fa222fad096f9ba837eab01ca6017cbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53a7df41e009d4a87e327717c3fa7058fa222fad096f9ba837eab01ca6017cbf->enter($__internal_53a7df41e009d4a87e327717c3fa7058fa222fad096f9ba837eab01ca6017cbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d1d5b96ccac9f9223ed0c019be640f3ffe653cac69486c0b983a0f67257cc5ce->leave($__internal_d1d5b96ccac9f9223ed0c019be640f3ffe653cac69486c0b983a0f67257cc5ce_prof);

        
        $__internal_53a7df41e009d4a87e327717c3fa7058fa222fad096f9ba837eab01ca6017cbf->leave($__internal_53a7df41e009d4a87e327717c3fa7058fa222fad096f9ba837eab01ca6017cbf_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_521f6c85950421dad89117534065737f5e5e740096591e197a4387b64ba80bf2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_521f6c85950421dad89117534065737f5e5e740096591e197a4387b64ba80bf2->enter($__internal_521f6c85950421dad89117534065737f5e5e740096591e197a4387b64ba80bf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_362b116bd1bae38d78b2a6a8ebe3fddc63a0b52d05e90fed9a7cf7256acb8956 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_362b116bd1bae38d78b2a6a8ebe3fddc63a0b52d05e90fed9a7cf7256acb8956->enter($__internal_362b116bd1bae38d78b2a6a8ebe3fddc63a0b52d05e90fed9a7cf7256acb8956_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_362b116bd1bae38d78b2a6a8ebe3fddc63a0b52d05e90fed9a7cf7256acb8956->leave($__internal_362b116bd1bae38d78b2a6a8ebe3fddc63a0b52d05e90fed9a7cf7256acb8956_prof);

        
        $__internal_521f6c85950421dad89117534065737f5e5e740096591e197a4387b64ba80bf2->leave($__internal_521f6c85950421dad89117534065737f5e5e740096591e197a4387b64ba80bf2_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ce4c1ffa850311f005c43e55650ed4416f6b50466a0b6f375e6889deadad1d4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce4c1ffa850311f005c43e55650ed4416f6b50466a0b6f375e6889deadad1d4b->enter($__internal_ce4c1ffa850311f005c43e55650ed4416f6b50466a0b6f375e6889deadad1d4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1dee459d54fe37f7f73d216df16214d814a48076ded28113773672622be2392d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1dee459d54fe37f7f73d216df16214d814a48076ded28113773672622be2392d->enter($__internal_1dee459d54fe37f7f73d216df16214d814a48076ded28113773672622be2392d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_1dee459d54fe37f7f73d216df16214d814a48076ded28113773672622be2392d->leave($__internal_1dee459d54fe37f7f73d216df16214d814a48076ded28113773672622be2392d_prof);

        
        $__internal_ce4c1ffa850311f005c43e55650ed4416f6b50466a0b6f375e6889deadad1d4b->leave($__internal_ce4c1ffa850311f005c43e55650ed4416f6b50466a0b6f375e6889deadad1d4b_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_6c9f50cfdad187c1e6cbd5d452db5f6816bdc21ecdea2b899298489aefaccbe6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c9f50cfdad187c1e6cbd5d452db5f6816bdc21ecdea2b899298489aefaccbe6->enter($__internal_6c9f50cfdad187c1e6cbd5d452db5f6816bdc21ecdea2b899298489aefaccbe6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_844ab59e131d455bbb299f6d566b2ba598e548db7d8c98e082d8bf116ef93a4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_844ab59e131d455bbb299f6d566b2ba598e548db7d8c98e082d8bf116ef93a4e->enter($__internal_844ab59e131d455bbb299f6d566b2ba598e548db7d8c98e082d8bf116ef93a4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_844ab59e131d455bbb299f6d566b2ba598e548db7d8c98e082d8bf116ef93a4e->leave($__internal_844ab59e131d455bbb299f6d566b2ba598e548db7d8c98e082d8bf116ef93a4e_prof);

        
        $__internal_6c9f50cfdad187c1e6cbd5d452db5f6816bdc21ecdea2b899298489aefaccbe6->leave($__internal_6c9f50cfdad187c1e6cbd5d452db5f6816bdc21ecdea2b899298489aefaccbe6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\sad\\Desktop\\New folder\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
