<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb3b24eb49daae1a6d1bfcae552f9db56a319f3931546f1e905beb58ae93db51 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb3b24eb49daae1a6d1bfcae552f9db56a319f3931546f1e905beb58ae93db51->enter($__internal_bb3b24eb49daae1a6d1bfcae552f9db56a319f3931546f1e905beb58ae93db51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_e0ab4936f6461e1c7d716756c22d70a57b09a535b1fd5ab7d11f2c7f78f085df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0ab4936f6461e1c7d716756c22d70a57b09a535b1fd5ab7d11f2c7f78f085df->enter($__internal_e0ab4936f6461e1c7d716756c22d70a57b09a535b1fd5ab7d11f2c7f78f085df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_bb3b24eb49daae1a6d1bfcae552f9db56a319f3931546f1e905beb58ae93db51->leave($__internal_bb3b24eb49daae1a6d1bfcae552f9db56a319f3931546f1e905beb58ae93db51_prof);

        
        $__internal_e0ab4936f6461e1c7d716756c22d70a57b09a535b1fd5ab7d11f2c7f78f085df->leave($__internal_e0ab4936f6461e1c7d716756c22d70a57b09a535b1fd5ab7d11f2c7f78f085df_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_859d5f29c0a81acee2311756e3b90de3c4ddfcf36465da312a722d127f511435 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_859d5f29c0a81acee2311756e3b90de3c4ddfcf36465da312a722d127f511435->enter($__internal_859d5f29c0a81acee2311756e3b90de3c4ddfcf36465da312a722d127f511435_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_187d44ea469407c8b9be79cae56d4ad24849d0a3593027d03ec98d0375a4a932 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_187d44ea469407c8b9be79cae56d4ad24849d0a3593027d03ec98d0375a4a932->enter($__internal_187d44ea469407c8b9be79cae56d4ad24849d0a3593027d03ec98d0375a4a932_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_187d44ea469407c8b9be79cae56d4ad24849d0a3593027d03ec98d0375a4a932->leave($__internal_187d44ea469407c8b9be79cae56d4ad24849d0a3593027d03ec98d0375a4a932_prof);

        
        $__internal_859d5f29c0a81acee2311756e3b90de3c4ddfcf36465da312a722d127f511435->leave($__internal_859d5f29c0a81acee2311756e3b90de3c4ddfcf36465da312a722d127f511435_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_24d8ff0ca38f1d82228bd4af09601eee3eb25623e48c2a5c7eed5e9caefb231f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24d8ff0ca38f1d82228bd4af09601eee3eb25623e48c2a5c7eed5e9caefb231f->enter($__internal_24d8ff0ca38f1d82228bd4af09601eee3eb25623e48c2a5c7eed5e9caefb231f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_9e355861025c1851fc5a4cdd6a28fe8c31dadd5cbc15f74581dd3ece907c5251 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e355861025c1851fc5a4cdd6a28fe8c31dadd5cbc15f74581dd3ece907c5251->enter($__internal_9e355861025c1851fc5a4cdd6a28fe8c31dadd5cbc15f74581dd3ece907c5251_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_9e355861025c1851fc5a4cdd6a28fe8c31dadd5cbc15f74581dd3ece907c5251->leave($__internal_9e355861025c1851fc5a4cdd6a28fe8c31dadd5cbc15f74581dd3ece907c5251_prof);

        
        $__internal_24d8ff0ca38f1d82228bd4af09601eee3eb25623e48c2a5c7eed5e9caefb231f->leave($__internal_24d8ff0ca38f1d82228bd4af09601eee3eb25623e48c2a5c7eed5e9caefb231f_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_6a5b51027cbdc1c0480bc67778aebc4220b1e75f6658e8bd73c8040e0b85556f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a5b51027cbdc1c0480bc67778aebc4220b1e75f6658e8bd73c8040e0b85556f->enter($__internal_6a5b51027cbdc1c0480bc67778aebc4220b1e75f6658e8bd73c8040e0b85556f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_ce081126c577feb645cb634311a073ba6fc76279bd827f248d9ace80878eb6d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce081126c577feb645cb634311a073ba6fc76279bd827f248d9ace80878eb6d1->enter($__internal_ce081126c577feb645cb634311a073ba6fc76279bd827f248d9ace80878eb6d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_ce081126c577feb645cb634311a073ba6fc76279bd827f248d9ace80878eb6d1->leave($__internal_ce081126c577feb645cb634311a073ba6fc76279bd827f248d9ace80878eb6d1_prof);

        
        $__internal_6a5b51027cbdc1c0480bc67778aebc4220b1e75f6658e8bd73c8040e0b85556f->leave($__internal_6a5b51027cbdc1c0480bc67778aebc4220b1e75f6658e8bd73c8040e0b85556f_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_9d1411d1e39b4228ca540a708a05472ed5a4c0deaa0369082d60c396ba76a44e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d1411d1e39b4228ca540a708a05472ed5a4c0deaa0369082d60c396ba76a44e->enter($__internal_9d1411d1e39b4228ca540a708a05472ed5a4c0deaa0369082d60c396ba76a44e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_7f722f575243443768827befad0930d5c0fef3a08cd33104d4894ec553d6b67b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f722f575243443768827befad0930d5c0fef3a08cd33104d4894ec553d6b67b->enter($__internal_7f722f575243443768827befad0930d5c0fef3a08cd33104d4894ec553d6b67b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_7f722f575243443768827befad0930d5c0fef3a08cd33104d4894ec553d6b67b->leave($__internal_7f722f575243443768827befad0930d5c0fef3a08cd33104d4894ec553d6b67b_prof);

        
        $__internal_9d1411d1e39b4228ca540a708a05472ed5a4c0deaa0369082d60c396ba76a44e->leave($__internal_9d1411d1e39b4228ca540a708a05472ed5a4c0deaa0369082d60c396ba76a44e_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_f854599381e1eff9ff71df7182a7a9182fbccce75d079179621e3693f281cef1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f854599381e1eff9ff71df7182a7a9182fbccce75d079179621e3693f281cef1->enter($__internal_f854599381e1eff9ff71df7182a7a9182fbccce75d079179621e3693f281cef1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e602c63cff2c3451eea21394bd80f5ab83c1556fc0536c48bb6a925d0ac41034 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e602c63cff2c3451eea21394bd80f5ab83c1556fc0536c48bb6a925d0ac41034->enter($__internal_e602c63cff2c3451eea21394bd80f5ab83c1556fc0536c48bb6a925d0ac41034_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_e602c63cff2c3451eea21394bd80f5ab83c1556fc0536c48bb6a925d0ac41034->leave($__internal_e602c63cff2c3451eea21394bd80f5ab83c1556fc0536c48bb6a925d0ac41034_prof);

        
        $__internal_f854599381e1eff9ff71df7182a7a9182fbccce75d079179621e3693f281cef1->leave($__internal_f854599381e1eff9ff71df7182a7a9182fbccce75d079179621e3693f281cef1_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_4c97a1b041bcbf66c4bd0693d4b06482288a8cc812e7b3b328996c37edd128c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c97a1b041bcbf66c4bd0693d4b06482288a8cc812e7b3b328996c37edd128c6->enter($__internal_4c97a1b041bcbf66c4bd0693d4b06482288a8cc812e7b3b328996c37edd128c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_a9459ce3b7ffa9158420b54a2a44236d96b0a07f2d82b2acd14b43710ca30527 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9459ce3b7ffa9158420b54a2a44236d96b0a07f2d82b2acd14b43710ca30527->enter($__internal_a9459ce3b7ffa9158420b54a2a44236d96b0a07f2d82b2acd14b43710ca30527_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_a9459ce3b7ffa9158420b54a2a44236d96b0a07f2d82b2acd14b43710ca30527->leave($__internal_a9459ce3b7ffa9158420b54a2a44236d96b0a07f2d82b2acd14b43710ca30527_prof);

        
        $__internal_4c97a1b041bcbf66c4bd0693d4b06482288a8cc812e7b3b328996c37edd128c6->leave($__internal_4c97a1b041bcbf66c4bd0693d4b06482288a8cc812e7b3b328996c37edd128c6_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_9d0ae2e576b4d665f3d92654d1299bd5b62f9627a6e1d2b20994557ebb546e6c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d0ae2e576b4d665f3d92654d1299bd5b62f9627a6e1d2b20994557ebb546e6c->enter($__internal_9d0ae2e576b4d665f3d92654d1299bd5b62f9627a6e1d2b20994557ebb546e6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_9615f950b2f7d3e0a45488b408c4707a693ec1cb3ee4c015b763f04029da490e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9615f950b2f7d3e0a45488b408c4707a693ec1cb3ee4c015b763f04029da490e->enter($__internal_9615f950b2f7d3e0a45488b408c4707a693ec1cb3ee4c015b763f04029da490e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_9615f950b2f7d3e0a45488b408c4707a693ec1cb3ee4c015b763f04029da490e->leave($__internal_9615f950b2f7d3e0a45488b408c4707a693ec1cb3ee4c015b763f04029da490e_prof);

        
        $__internal_9d0ae2e576b4d665f3d92654d1299bd5b62f9627a6e1d2b20994557ebb546e6c->leave($__internal_9d0ae2e576b4d665f3d92654d1299bd5b62f9627a6e1d2b20994557ebb546e6c_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_0494427f05f7a0189b7db83acbebbb9dcce4ab74a10eef75a7836c23c5317ac4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0494427f05f7a0189b7db83acbebbb9dcce4ab74a10eef75a7836c23c5317ac4->enter($__internal_0494427f05f7a0189b7db83acbebbb9dcce4ab74a10eef75a7836c23c5317ac4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a13001a92f76b0c32eb429a9f0332b294f1ccf14d59e3d7bf140542882b70b4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a13001a92f76b0c32eb429a9f0332b294f1ccf14d59e3d7bf140542882b70b4f->enter($__internal_a13001a92f76b0c32eb429a9f0332b294f1ccf14d59e3d7bf140542882b70b4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_a13001a92f76b0c32eb429a9f0332b294f1ccf14d59e3d7bf140542882b70b4f->leave($__internal_a13001a92f76b0c32eb429a9f0332b294f1ccf14d59e3d7bf140542882b70b4f_prof);

        
        $__internal_0494427f05f7a0189b7db83acbebbb9dcce4ab74a10eef75a7836c23c5317ac4->leave($__internal_0494427f05f7a0189b7db83acbebbb9dcce4ab74a10eef75a7836c23c5317ac4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Users\\sad\\Desktop\\New folder\\app\\Resources\\views\\base.html.twig");
    }
}
