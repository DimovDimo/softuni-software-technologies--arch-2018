<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bf377e8189b12d75163cde31963add5b22c678b5f729ad53c4f089d5c626724 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bf377e8189b12d75163cde31963add5b22c678b5f729ad53c4f089d5c626724->enter($__internal_8bf377e8189b12d75163cde31963add5b22c678b5f729ad53c4f089d5c626724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_36469beab693fed3255f5d641858c2897327c93b1c81ab7717b36c8aa91dda1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36469beab693fed3255f5d641858c2897327c93b1c81ab7717b36c8aa91dda1e->enter($__internal_36469beab693fed3255f5d641858c2897327c93b1c81ab7717b36c8aa91dda1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8bf377e8189b12d75163cde31963add5b22c678b5f729ad53c4f089d5c626724->leave($__internal_8bf377e8189b12d75163cde31963add5b22c678b5f729ad53c4f089d5c626724_prof);

        
        $__internal_36469beab693fed3255f5d641858c2897327c93b1c81ab7717b36c8aa91dda1e->leave($__internal_36469beab693fed3255f5d641858c2897327c93b1c81ab7717b36c8aa91dda1e_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_55fbe2c440ac8399916aba1767c91470124b3c47e53d526b6adab5a6d215010b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_55fbe2c440ac8399916aba1767c91470124b3c47e53d526b6adab5a6d215010b->enter($__internal_55fbe2c440ac8399916aba1767c91470124b3c47e53d526b6adab5a6d215010b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_0460864ef6efa13b1dbbf3c10f8b39767e15b713e1bd9f7bea81f87ff3acb8eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0460864ef6efa13b1dbbf3c10f8b39767e15b713e1bd9f7bea81f87ff3acb8eb->enter($__internal_0460864ef6efa13b1dbbf3c10f8b39767e15b713e1bd9f7bea81f87ff3acb8eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_0460864ef6efa13b1dbbf3c10f8b39767e15b713e1bd9f7bea81f87ff3acb8eb->leave($__internal_0460864ef6efa13b1dbbf3c10f8b39767e15b713e1bd9f7bea81f87ff3acb8eb_prof);

        
        $__internal_55fbe2c440ac8399916aba1767c91470124b3c47e53d526b6adab5a6d215010b->leave($__internal_55fbe2c440ac8399916aba1767c91470124b3c47e53d526b6adab5a6d215010b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_47312d1de7f2a5bd06d54babb12dbf811e5b3f19cb9e8f084ad1c71675e0106d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47312d1de7f2a5bd06d54babb12dbf811e5b3f19cb9e8f084ad1c71675e0106d->enter($__internal_47312d1de7f2a5bd06d54babb12dbf811e5b3f19cb9e8f084ad1c71675e0106d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d5ad527845acd2a34e16787891e136aca0231e68249f2974a21bf58ced5fd5ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5ad527845acd2a34e16787891e136aca0231e68249f2974a21bf58ced5fd5ac->enter($__internal_d5ad527845acd2a34e16787891e136aca0231e68249f2974a21bf58ced5fd5ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_d5ad527845acd2a34e16787891e136aca0231e68249f2974a21bf58ced5fd5ac->leave($__internal_d5ad527845acd2a34e16787891e136aca0231e68249f2974a21bf58ced5fd5ac_prof);

        
        $__internal_47312d1de7f2a5bd06d54babb12dbf811e5b3f19cb9e8f084ad1c71675e0106d->leave($__internal_47312d1de7f2a5bd06d54babb12dbf811e5b3f19cb9e8f084ad1c71675e0106d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_28e8b321e6b5717c13355feb4689a1b078d5a369f0eebef1136974dc6b591780 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_28e8b321e6b5717c13355feb4689a1b078d5a369f0eebef1136974dc6b591780->enter($__internal_28e8b321e6b5717c13355feb4689a1b078d5a369f0eebef1136974dc6b591780_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_6442968c71fa21d94f877ef37c6842149350843ef23335bb3fd38b0601171c28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6442968c71fa21d94f877ef37c6842149350843ef23335bb3fd38b0601171c28->enter($__internal_6442968c71fa21d94f877ef37c6842149350843ef23335bb3fd38b0601171c28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_6442968c71fa21d94f877ef37c6842149350843ef23335bb3fd38b0601171c28->leave($__internal_6442968c71fa21d94f877ef37c6842149350843ef23335bb3fd38b0601171c28_prof);

        
        $__internal_28e8b321e6b5717c13355feb4689a1b078d5a369f0eebef1136974dc6b591780->leave($__internal_28e8b321e6b5717c13355feb4689a1b078d5a369f0eebef1136974dc6b591780_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\sad\\Desktop\\New folder\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
