const user = require('./user');
const home = require('./home');

module.exports = {
    user,
    home,
};