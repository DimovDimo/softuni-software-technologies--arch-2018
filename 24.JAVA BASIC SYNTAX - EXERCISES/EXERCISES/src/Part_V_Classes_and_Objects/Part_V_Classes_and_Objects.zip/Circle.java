package Part_V_Classes_and_Objects;

public class Circle {
    private Point center;
    private int redius;

    public Circle(Point center, int redius) {
        this.center = center;
        this.redius = redius;
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public int getRedius() {
        return redius;
    }

    public void setRedius(int redius) {
        this.redius = redius;
    }
}
